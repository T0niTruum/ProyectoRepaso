package ejecucion;

public class ClienteJuridico {
    
}
