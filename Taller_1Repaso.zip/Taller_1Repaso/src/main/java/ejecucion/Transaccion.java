package ejecucion;

public class Transaccion {
    
}
