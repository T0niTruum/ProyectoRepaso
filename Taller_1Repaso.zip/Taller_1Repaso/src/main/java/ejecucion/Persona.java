package ejecucion;

public class Persona {
    private String nom, ident ;
}
