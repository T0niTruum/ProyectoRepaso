package ejecucion;

public class ClienteNatural {
    
}
